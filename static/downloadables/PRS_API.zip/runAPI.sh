#!/bin/bash

# Calls a python function to get a list of SNPs from our database
eval res=($(python3 -c 'import vcf_parser_grep as pg; pg.grepRes()'))

# Filters the input VCF to only include the lines that correspond to the SNPs in our GWAS database
grep -w ${res[0]} $1 > intermediate.vcf #TODO param for ouput
tableObj=${res[1]}
# Runs a python script to calculate PRS on the filtered VCF
python3 run_prs_grep.py intermediate.vcf $2 $3 $4 "${tableObj}"

#TODO- have fail safes if some of these are empty- better ordering for params so empties are at the end?
#1 file name
#2 output file name
#3 diseaseList
#4 studyType
#5 pValue
#6 refGen
#7- cvs (T), json (F)

#TODO
#getSNPsFromTableObj- combine this with getSNPsFromGrep
#too many parameters for calculate function?
#can we remove the intermediate file and pipe instead? If not, delete if after the function runs