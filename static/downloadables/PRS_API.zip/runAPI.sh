#!/bin/bash

# v1.0.0
# Parameter order:
#1 VCF file path
#2 output file path (csv or txt format)
#3 p-value cutoff (ex: 0.05)
#4 refGen {hg17, hg18, hg19, hg38}

#TODO- features to be added soon
#opt diseaseList
#opt output type- csv, json (optional)
#opt studyType- large cohort(l), high impact(h) (optional)

if [ $# -lt 4 ]; then
    echo "Too few arguments! Usage:"
    echo "runAPI.sh [VCF file path] [output file path (csv or txt format)] [p-value cutoff (ex: 0.05)] [refGen {hg17, hg18, hg19, hg38}]"
    read -p "Press [Enter] key to quit..."
elif [ ! -f "$1" ]; then
    echo "The file $1 does not exist."
    echo "Check the path and try again."
    read -p "Press [Enter] key to quit..."
elif ! [[ "$3" =~ ^[0-9]*(\.[0-9]+)?$ ]]; then
    echo "$3 is your p-value, but it is not a number."
    echo "Check the value and try again."
    read -p "Press [Enter] key to quit..."
elif ! [[ "$4" == 'hg17' ]] && ! [[ "$4" = 'hg19' ]] && ! [[ "$4" == 'hg18' ]] && ! [[ "$4" == 'hg38' ]]; then
    echo "$4 should be hg17, hg18, hg19, or hg38"
    echo "Check the value and try again."
    read -p "Press [Enter] key to quit..."
else
    echo "Running PRSKB on $1"
    # Calls a python function to get a list of SNPs from our database
    # res is a string composed of two strings separated by a '%'
    # The string is split into a list containing both strings
    res=$(python -c "import vcf_parser_grep as pg; pg.grepRes('[]', 'all', '$3', '$4')")
    declare -a resArr
    IFS='%' # percent (%) is set as delimiter
    read -ra ADDR <<< "$res" # res is read into an array as tokens separated by IFS
    for i in "${ADDR[@]}"; do # access each element of array
        resArr+=( "$i" )
    done
    IFS=' ' # reset to default value after usage
    echo ${resArr[1]} > tableObj.txt
    echo "Got SNPs and disease information from PRSKB"

    # Filters the input VCF to only include the lines that correspond to the SNPs in our GWAS database
    grep -w ${resArr[0]} "$1" > intermediate.vcf
    # prints out the tableObj string to a file so python can read it in
    # (passing the string as a parameter doesn't work because it is too large)
    echo "Greped the VCF file"

    outputType="csv" #this is the default
    #$1=intermediateFile $2=diseaseArray $3=pValue $4=csv $5="${tableObj}" $6=outputFile
    python run_prs_grep.py intermediate.vcf "$diseaseArray" "$3" "$outputType" tableObj.txt "$2"
    echo "Caculated score"
    rm intermediate.vcf
    rm tableObj.txt
    echo "Cleaned up intermediate files"
    echo "Results saved to $2"
    echo ""
    read -p "Press [Enter] key to finish..."
fi
