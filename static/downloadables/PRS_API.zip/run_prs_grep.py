import vcf_parser_grep  as pg
import time
import sys

#start = time.time()
diseaseList = []
#TODO diseaseList is hardcoded, but should go here
results = pg.calculateScore(sys.argv[1], diseaseList, sys.argv[3], sys.argv[4], sys.argv[5])
#end = time.time()
#print(end - start)
f = open(sys.argv[2], 'w')
f.write(results)
f.close()