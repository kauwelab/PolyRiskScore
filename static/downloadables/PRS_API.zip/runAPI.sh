#!/bin/bash

#Submit this script with: sbatch thefilename

#SBATCH --time=1:00:00  # walltime
#SBATCH --ntasks=1  # number of processor cores (i.e. tasks)
#SBATCH --nodes=1  # number of nodes
#SBATCH --mem=60G  # memory CPU core
#SBATCH -J "COUSINS"
#SBATCH --mail-user=elizabethvance03@gmail.com   # email address
#SBATCH --mail-type=BEGIN
#SBATCH --mail-type=END
#SBATCH --mail-type=FAIL

# Calls a python function to get a list of SNPs from our database
SNPS="$(python3 -c 'import vcf_parser_grep as pg; pg.getSNPsforGrep()')"

# Filters the input VCF to only include the lines that correspond to the SNPs in our GWAS database
grep -w ${SNPS} $1 > filteredInput.vcf

# Runs a python script to calculate PRS on the filtered VCF
python3 run_prs_grep.py filteredInput.vcf $2 $3 $4

