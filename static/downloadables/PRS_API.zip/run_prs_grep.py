import vcf_parser_grep  as pg
import time
import sys

start = time.time()

diseaseList = []
diseaseList.append("AD")
#diseaseList.append("ALS")
#results = vp.calculateScore("ad test.vcf", [], 1e-3)
#results = vp.calculateScore("C:/Users/Matthew Cloward/Desktop/Home Work/Lab BioInfo/Test data/adgc_hrc_combined_chr11.vcf.gz", diseaseList, 1e-3)
results = pg.calculateScore(sys.argv[1], diseaseList, sys.argv[3], sys.argv[4])
end = time.time()
print(end - start)
f = open(sys.argv[2], 'w')
f.write(results)
f.close()
#print(results)

